<script>
  import { onMount } from 'svelte';
  import { fade } from 'svelte/transition';
  import { page } from '$app/stores';

  let isOnline = $state(true);

  onMount(() => {
    isOnline = navigator.onLine;
    window.addEventListener('online', () => (isOnline = true));
    window.addEventListener('offline', () => (isOnline = false));
  });
</script>

<header>
  <div class="title">Tågförseningar</div>
  <nav>
    <a href="/" class:active={$page.url.pathname === '/'}>Lista</a>
    <a href="/karta" class:active={$page.url.pathname === '/karta'}>Karta</a>
  </nav>
</header>

{#if !isOnline}
  <div class="offline-banner">
    ⚠️ Du är offline — data kan vara inaktuell.
  </div>
{/if}

<main>
  {#key $page.url.pathname}
    <div in:fade={{ duration: 150 }}>
      <slot />
    </div>
  {/key}
</main>

<style>
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background: #2b3a55;
    color: white;
    position: sticky;
    top: 0;
    z-index: 20;
  }
  .title { font-weight: bold; }
  nav {
    display: flex;
    gap: 1rem;
  }
  nav a {
    color: white;
    text-decoration: none;
    opacity: 0.7;
    font-size: 0.9rem;
  }
  nav a.active {
    opacity: 1;
    font-weight: bold;
    border-bottom: 2px solid white;
  }
  .offline-banner {
    background: #ffe08a;
    color: #5a4300;
    text-align: center;
    padding: 0.5rem;
    font-size: 0.9rem;
  }
  main {
    max-width: 600px;
    margin: 0 auto;
    padding: 1rem;
  }
</style>
