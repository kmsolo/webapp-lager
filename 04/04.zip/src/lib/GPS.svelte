<script>
  let location = null
  let locationError = ''
  let gettingLocation = false
  
  // Callback som föräldern kan binda till
  let onsaved

  function getLocation() {
    locationError = ''
    location = null

    if (!navigator.geolocation) {
      locationError = 'Din webbläsare har inte stöd för GPS-positionering.'
      return
    }

    gettingLocation = true

    navigator.geolocation.getCurrentPosition(
      (position) => {
        location = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: Math.round(position.coords.accuracy),
        }
        gettingLocation = false
        
        // Använd callback istället för dispatch
        if (onsaved) {
          onsaved(location)
        }
      },
      (error) => {
        const messages = {
          1: 'Du nekade tillåtelse att använda positionen.',
          2: 'Det gick inte att fastställa positionen.',
          3: 'Tidsgränsen för att hämta positionen gick ut.',
        }
        locationError = messages[error.code] ?? 'Ett okänt fel uppstod.'
        gettingLocation = false
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    )
  }

  function openMap() {
    if (!location) return

    const { latitude, longitude } = location
    const url = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=16/${latitude}/${longitude}`
    window.open(url, '_blank', 'noopener,noreferrer')
  }
</script>

<section class="card">
  <h2 class="section-title">📍 Hämta GPS-position</h2>

  <div class="gps-container" style="margin-top: 1rem;">
    <button class="primary-btn" type="button" onclick={getLocation} disabled={gettingLocation}>
      {#if gettingLocation}
        🔄 Hämtar...
      {:else}
        📍 Hämta min position
      {/if}
    </button>

    {#if locationError}
      <p class="error-message" style="margin-top: 1rem; color: #c00;">⚠️ {locationError}</p>
    {/if}

    {#if location}
      <div class="gps-info" style="margin-top: 1rem; padding: 0.75rem; background: #fffafc; border: 1px solid var(--card-border); border-radius: 8px;">
        <p><strong>Latitud:</strong> {location.latitude.toFixed(6)}</p>
        <p><strong>Longitud:</strong> {location.longitude.toFixed(6)}</p>
        <p><strong>Ungefärlig noggrannhet:</strong> ±{location.accuracy} meter</p>
        <button class="secondary-btn" type="button" onclick={openMap} style="margin-top: 0.5rem;">🗺️ Visa på karta</button>
      </div>
    {/if}
  </div>
</section>