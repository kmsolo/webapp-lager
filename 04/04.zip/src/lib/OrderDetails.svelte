<!-- src/lib/OrderDetails.svelte -->
<script>
  export let selectedOrder = null

  function back() {
    // Hanteras av föräldern
  }
</script>

<section class="card" aria-labelledby="order-details-title">
  <button class="secondary-btn" type="button" onclick={() => window.history.back()}>
    ← Tillbaka till ordrar
  </button>

  <h2 id="order-details-title" class="section-title">Order #{selectedOrder.id}</h2>

  <div class="order-details">
    <p><strong>Kund:</strong> {selectedOrder.customer}</p>
    <p><strong>Produkt:</strong> {selectedOrder.product_name ?? 'Okänd produkt'}</p>
    <p><strong>Antal:</strong> {selectedOrder.quantity} st</p>
    <p><strong>Pris:</strong> {selectedOrder.unit_price} kr</p>
    <p><strong>Lagerplats:</strong> {selectedOrder.product_location ?? '-'}</p>
    <p><strong>Datum:</strong> {selectedOrder.created_at}</p>
    <p><strong>Status:</strong> Packad (200)</p>
  </div>

  <div class="btn-row">
    <button class="primary-btn" type="button" onclick={() => window.location.hash = 'gps'}>
      📍 Hämta GPS-position
    </button>
    <button class="primary-btn" type="button" onclick={() => window.location.hash = 'camera'}>
      📷 Ta leveransfoto
    </button>
  </div>
</section>