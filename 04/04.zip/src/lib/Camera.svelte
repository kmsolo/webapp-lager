<script>
  let selectedImageUrl = ''
  let uploading = false
  
  // Callback som föräldern kan binda till
  let onsaved
  
  function handleImageChange(event) {
    const file = event.currentTarget.files?.[0]
    if (!file) return

    uploading = true

    const uuid = crypto.randomUUID()
    const upload = window.fileUploaderUpload({
      uuid,
      url: 'https://upload.uploadcare.com',
      publicKey: 'd99b6b78367c805196b5',
      files: [file],
      onProgress: (data) => {
        console.log('Uppladdning pågår:', data)
      },
      onFileProgress: (data) => {
        console.log('Filuppladdning pågår:', data)
      },
    })

    upload
      .start()
      .done((fileInfo) => {
        console.log('Uppladdning klar!', fileInfo)
        uploading = false
        selectedImageUrl = fileInfo.cdnUrl
        
        // Använd callback istället för dispatch
        if (onsaved) {
          onsaved(selectedImageUrl)
        }
      })
      .fail((error) => {
        console.error('Uppladdning misslyckades:', error)
        uploading = false
        alert('Kunde inte ladda upp bilden. Försök igen.')
      })
  }
</script>

<section class="card">
  <h2 class="section-title">📷 Ta leveransfoto</h2>

  <div class="camera-container" style="margin-top: 1rem;">
    <input
      type="file"
      accept="image/*"
      capture="environment"
      onchange={handleImageChange}
      disabled={uploading}
      style="width: 100%; padding: 0.75rem; border: 2px dashed var(--card-border); border-radius: 8px; background: #fafafa;"
    />

    {#if uploading}
      <p style="margin-top: 1rem; color: #666;">🔄 Laddar upp bild...</p>
    {/if}

    {#if selectedImageUrl}
      <div style="margin-top: 1rem;">
        <p style="margin-bottom: 0.5rem; font-weight: 600;">✅ Bild uppladdad!</p>
        <img 
          src={selectedImageUrl} 
          alt="Leveransfoto" 
          style="width: 100%; max-width: 400px; border-radius: 8px; border: 1px solid var(--card-border);"
        />
        <p style="margin-top: 0.5rem; font-size: 0.875rem; color: #666;">
          Bild-URL: <code style="background: #f0f0f0; padding: 2px 6px; border-radius: 4px;">{selectedImageUrl.substring(0, 50)}...</code>
        </p>
      </div>
    {/if}
  </div>
</section>