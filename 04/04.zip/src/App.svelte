<!-- src/App.svelte -->
<script>
  import { onMount } from 'svelte'
  import { fade, fly } from 'svelte/transition'

  import Products from './lib/Products.svelte'
  import ProductForm from './lib/ProductForm.svelte'
  import Deliveries from './lib/Deliveries.svelte'
  import DeliveryForm from './lib/DeliveryForm.svelte'
  import Orders from './lib/Orders.svelte'
  import GPS from './lib/GPS.svelte'
  import Camera from './lib/Camera.svelte'

  const apiUrl = 'http://localhost:3001'

  let activeView = 'products'
  let products = []
  let selectedOrder = null
  
  // För att spara GPS och foto från komponenterna
  let savedLocation = null
  let savedImageUrl = ''

  onMount(() => {
    loadProducts()
  })

  function showView(view) {
    activeView = view
    selectedOrder = null
  }

  async function loadProducts() {
    try {
      const response = await fetch(`${apiUrl}/products`)
      if (!response.ok) throw new Error(`HTTP-fel: ${response.status}`)
      products = await response.json()
    } catch (error) {
      console.error('Kunde inte hämta produkter:', error)
    }
  }

  function openNewProduct() {
    activeView = 'new-product'
  }

  function openEditProduct(event) {
    selectedOrder = { editProduct: event.detail }
    activeView = 'edit-product'
  }

  async function deleteProduct(event) {
    await loadProducts()
  }

  function openOrder(order) {
    selectedOrder = order
    activeView = 'order-details'
  }

  function handleGPSSaved(location) {
    savedLocation = location
  }

  function handleCameraSaved(url) {
    savedImageUrl = url
  }

  async function confirmDelivery() {
    if (!selectedOrder || !savedLocation) {
      alert('Du måste hämta GPS-position först!')
      return
    }

    const confirmed = window.confirm('Bekräfta att ordern är levererad?')
    if (!confirmed) return

    try {
      const response = await fetch(`${apiUrl}/orders/${selectedOrder.id}/deliver`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          latitude: savedLocation.latitude,
          longitude: savedLocation.longitude,
          photo_url: savedImageUrl || null,
        }),
      })

      if (!response.ok) throw new Error(`HTTP-fel: ${response.status}`)

      const updatedOrder = await response.json()
      selectedOrder = updatedOrder
      
      // Rensa sparade värden
      savedLocation = null
      savedImageUrl = ''
      
      alert('Leverans bekräftad! 🎉')
      showView('orders')
    } catch (error) {
      console.error('Kunde inte bekräfta leverans:', error)
      alert('Kunde inte bekräfta leverans. Försök igen.')
    }
  }
</script>

<svelte:head>
  <title>Lagerapp – Del 4</title>
  <meta name="description" content="Lagerapp med produkter, inleveranser, ordrar, GPS och kamera." />
</svelte:head>

<header class="topbar">
  <div class="header-inner">
    <h1>Lagerapp – Del 4</h1>
    <nav class="app-nav" aria-label="Huvudmeny">
      <button class="nav-btn" class:active-nav={activeView === 'products'} type="button" onclick={() => showView('products')}>📦 Produkter</button>
      <button class="nav-btn" type="button" onclick={openNewProduct}>🎁 Ny produkt</button>
      <button class="nav-btn" class:active-nav={activeView === 'deliveries'} type="button" onclick={() => showView('deliveries')}>📥 Inleveranser</button>
      <button class="nav-btn" type="button" onclick={() => showView('new-delivery')}>➕ Ny inleverans</button>
      <button class="nav-btn" class:active-nav={activeView === 'orders'} type="button" onclick={() => showView('orders')}>🚚 Ordrar</button>
      <button class="nav-btn" class:active-nav={activeView === 'gps'} type="button" onclick={() => showView('gps')}>📍 GPS</button>
      <button class="nav-btn" class:active-nav={activeView === 'camera'} type="button" onclick={() => showView('camera')}>📷 Kamera</button>
    </nav>
  </div>
</header>

<main>
  {#key activeView}
    <div in:fly={{ x: 18, duration: 180 }} out:fade={{ duration: 120 }}>
      {#if activeView === 'products'}
        <Products {products} {apiUrl} on:editProduct={openEditProduct} on:deleteProduct={deleteProduct} />

      {:else if activeView === 'new-product'}
        <ProductForm {apiUrl} mode="create" on:saved={() => { loadProducts(); showView('products') }} on:cancel={() => showView('products')} />

      {:else if activeView === 'edit-product' && selectedOrder?.editProduct}
        <ProductForm {apiUrl} mode="edit" product={selectedOrder.editProduct} on:saved={() => { loadProducts(); showView('products') }} on:cancel={() => showView('products')} />

      {:else if activeView === 'deliveries'}
        <Deliveries {apiUrl} />

      {:else if activeView === 'new-delivery'}
        <DeliveryForm {apiUrl} />

      {:else if activeView === 'orders'}
        <Orders {apiUrl} {openOrder} />

      {:else if activeView === 'gps'}
        <GPS bind:onsaved={handleGPSSaved} />

      {:else if activeView === 'camera'}
        <Camera bind:onsaved={handleCameraSaved} />

      {:else if activeView === 'order-details' && selectedOrder}
        <section class="card">
          <button class="secondary-btn" type="button" onclick={() => showView('orders')}>← Tillbaka till ordrar</button>
          <h2 class="section-title">Order #{selectedOrder.id}</h2>
          
          <div class="order-details">
            <p><strong>Kund:</strong> {selectedOrder.customer}</p>
            <p><strong>Produkt:</strong> {selectedOrder.product_name ?? 'Okänd'}</p>
            <p><strong>Antal:</strong> {selectedOrder.quantity} st</p>
            <p><strong>Pris:</strong> {selectedOrder.unit_price} kr</p>
            <p><strong>Lagerplats:</strong> {selectedOrder.product_location ?? '-'}</p>
            <p><strong>Datum:</strong> {selectedOrder.created_at}</p>
            <p><strong>Status:</strong> {selectedOrder.status === 'packad' ? 'Packad (200)' : 'Levererad'}</p>
            
            {#if selectedOrder.delivered_latitude && selectedOrder.delivered_longitude}
              <div class="delivery-info" style="margin-top: 1rem; padding: 0.75rem; background: #fffafc; border: 1px solid var(--card-border); border-radius: 8px;">
                <p><strong>Levererad:</strong> {selectedOrder.delivered_at}</p>
                <p><strong>GPS:</strong> {selectedOrder.delivered_latitude.toFixed(6)}, {selectedOrder.delivered_longitude.toFixed(6)}</p>
                {#if selectedOrder.delivery_photo}
                  <p><strong>Foto:</strong> <a href={selectedOrder.delivery_photo} target="_blank" rel="noopener noreferrer">Visa leveransfoto</a></p>
                {/if}
              </div>
            {/if}
          </div>

          {#if selectedOrder.status === 'packad'}
            <!-- Statusindikatorer -->
            <div style="margin-top: 1rem; padding: 0.75rem; background: #f5f5f5; border-radius: 8px;">
              <p style="margin-bottom: 0.5rem; font-weight: 600;">Leveransförberedelser:</p>
              <p style="color: {savedLocation ? 'green' : '#666'};">
                {savedLocation ? '✅' : '⬜'} GPS: {savedLocation ? `${savedLocation.latitude.toFixed(4)}, ${savedLocation.longitude.toFixed(4)}` : 'Inte hämtad'}
              </p>
              <p style="color: {savedImageUrl ? 'green' : '#666'};">
                {savedImageUrl ? '✅' : '⬜'} Foto: {savedImageUrl ? 'Uppladdat' : 'Inte taget'}
              </p>
            </div>

            <div class="btn-row" style="margin-top: 1rem;">
              <button class="primary-btn" type="button" onclick={() => showView('gps')}>📍 Hämta GPS</button>
              <button class="primary-btn" type="button" onclick={() => showView('camera')}>📷 Ta foto</button>
              <button class="danger-btn" type="button" onclick={confirmDelivery} disabled={!savedLocation}>Bekräfta leverans</button>
            </div>
          {/if}
        </section>
      {/if}
    </div>
  {/key}
</main>