// api/routes/orders.js
import express from "express";
import db from "../db.js";

const router = express.Router();

router.get("/", (req, res) => {
  const { status } = req.query;

  let sql = `
    SELECT 
      orders.id,
      orders.customer,
      orders.product_id,
      orders.quantity,
      orders.unit_price,
      orders.status,
      orders.created_at,
      products.name AS product_name,
      products.location AS product_location
    FROM orders
    JOIN products ON orders.product_id = products.id
  `;

  const params = [];

  if (status) {
    sql += " WHERE orders.status = ?";
    params.push(status);
  }

  sql += " ORDER BY orders.created_at DESC";

  const stmt = db.prepare(sql);
  const orders = stmt.all(...params);

  res.json(orders);
});

router.get("/:id", (req, res) => {
  const stmt = db.prepare(`
    SELECT 
      orders.id,
      orders.customer,
      orders.product_id,
      orders.quantity,
      orders.unit_price,
      orders.status,
      orders.created_at,
      products.name AS product_name,
      products.location AS product_location
    FROM orders
    JOIN products ON orders.product_id = products.id
    WHERE orders.id = ?
  `);
  const order = stmt.get(req.params.id);

  if (!order) {
    return res.status(404).json({ error: "Ordern hittades inte." });
  }

  res.json(order);
});

router.put("/:id/status", (req, res) => {
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ error: "Status måste anges." });
  }

  const stmt = db.prepare("UPDATE orders SET status = ? WHERE id = ?");
  stmt.run(status, req.params.id);

  const updatedOrder = db
    .prepare(
      `
      SELECT 
        orders.id,
        orders.customer,
        orders.product_id,
        orders.quantity,
        orders.unit_price,
        orders.status,
        orders.created_at,
        products.name AS product_name,
        products.location AS product_location
      FROM orders
      JOIN products ON orders.product_id = products.id
      WHERE orders.id = ?
    `,
    )
    .get(req.params.id);

  res.json(updatedOrder);
});

// Testroute för att packa en order
router.get("/test-pack-order/:id", (req, res) => {
  const stmt = db.prepare("UPDATE orders SET status = ? WHERE id = ?");
  stmt.run("packad", req.params.id);

  const order = db
    .prepare("SELECT * FROM orders WHERE id = ?")
    .get(req.params.id);

  res.json({ message: `Order ${req.params.id} är nu packad.`, order });
});
// Lägg till detta i slutet av filen, före exporten

// Uppdatera order som levererad med GPS och foto
router.put("/:id/deliver", (req, res) => {
  const { latitude, longitude, photo_url } = req.body;

  if (!latitude || !longitude) {
    return res.status(400).json({ error: "GPS-koordinater krävs." });
  }

  // Uppdatera ordern
  const updateOrder = db.prepare(`
    UPDATE orders 
    SET status = 'levererad',
        delivered_latitude = ?,
        delivered_longitude = ?,
        delivery_photo = ?,
        delivered_at = datetime('now')
    WHERE id = ?
  `);

  try {
    updateOrder.run(latitude, longitude, photo_url || null, req.params.id);

    const updatedOrder = db
      .prepare(
        `
      SELECT 
        orders.id,
        orders.customer,
        orders.product_id,
        orders.quantity,
        orders.unit_price,
        orders.status,
        orders.created_at,
        orders.delivered_latitude,
        orders.delivered_longitude,
        orders.delivery_photo,
        orders.delivered_at,
        products.name AS product_name,
        products.location AS product_location
      FROM orders
      JOIN products ON orders.product_id = products.id
      WHERE orders.id = ?
    `,
      )
      .get(req.params.id);

    res.json(updatedOrder);
  } catch (error) {
    console.error("Kunde inte uppdatera order:", error);
    res
      .status(500)
      .json({
        error:
          "Kunde inte uppdatera order. Kontrollera att databasen har rätt kolumner.",
      });
  }
});
export default router;
